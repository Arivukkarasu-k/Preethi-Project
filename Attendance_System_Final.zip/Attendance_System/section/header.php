<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="stylesheet" type="text/css" href="./../css/side_nav.css">
     <link rel="stylesheet" type="text/css" href="./../css/table.css">
     <link rel="stylesheet" type="text/css" href="./../css/error.css">
     <link rel="stylesheet" type="text/css" href="./../css/ribbon.css">
     <link rel="stylesheet" type="text/css" href="./../css/pop_up.css">

   </head>